
print ("Hello from Python")