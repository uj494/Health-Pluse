var express = require('express');
var session = require('express-session');
var app = express();
var http = require('http');
var server = http.createServer(app);
var io = require('socket.io').listen(server);
var fs = require("fs");
var TimSort = require('timsort');
var dateFormat = require('dateformat');
var PythonShell = require('python-shell');

app.use(session({
  secret: 'max',
  resave: false,
  saveUninitialized: false
}));


app.use(express.static(__dirname + '/public'));

app.set('view engine', 'ejs');

process.on('uncaughtException', function(err) { 
    console.log( " UNCAUGHT EXCEPTION " );
    console.log( "[Inside 'uncaughtException' event] " + err.stack || err.message );
	
	app.get('/error', function(req, res){

	res.writeHead(200, {'Content-Type': 'text/plain'});
    res.end('OK');
});

});

var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://localhost:27017/';

server.listen(3000);




users = [];
connections = [];




    
    io.sockets.on('connection', function(socket){
       //connect
       connections.push(socket);
       console.log('Connected: %s sockets connected', connections.length);
       
       //disconnect
         socket.on('disconnect', function(data){
          //users.splice(users.indexOf(socket.username), 1);
          // updateUsernames();
         connections.splice(connections.indexOf(socket), 1);
         console.log('Disconnected: %s sockets connected', connections.length);   
       });
       //Send messages
       socket.on('send message', function(data){
         io.sockets.emit('new message', data);
         data.timestamp = Date.now();
         MongoClient.connect(url, function(err, db) {
 	 	if (err) throw err;
  		var dbo = db.db("healthplus");
  		var myobj = data;
  		dbo.collection("chat").insertOne(myobj, function(err, res) {
    	if (err) throw err;
    		console.log("1 document inserted");
    		db.close();
  			});
		});
       });
       
       //new user
       socket.on('new user', function(data, callback){
         callback(true);
         socket.username = data;
         users.push(socket.username);
         updateUsernames();
       });
       
       function updateUsernames(){
         io.sockets.emit('get users', users);
       }
      });










app.get('/temp', function(req, res){

	var uname = req.query.user;
	var data = req.query.res;

	io.emit('temp', {value : data+"" , uname : uname+""});
	
	if(data != -1){

	MongoClient.connect(url, function(err, db) {
 	 	if (err) throw err;
  		var dbo = db.db("healthplus");
  		var myobj = { uname: uname+"", data: data+"", unit: "°F", timestamp: new Date().toString()+"" };
  		dbo.collection("temperature").insertOne(myobj, function(err, res) {
    	if (err) throw err;
    	console.log("1 document inserted");
		if(parseFloat(data) > 100.0 || parseFloat(data) < 97.5){
		dbo.collection("users").findOne({uname: uname+""},function(err, result) {
			dbo.collection("doctor").find({"uname" : { $in : result.docid  } } ).toArray(function(err, resultDoc) { 
				if (err) throw err;
				var msg = "From "+ uname + ",\nHealth Plus Alert!\nBody Temp : " + data + "\n\n" + "Patient needs Medical Attention.";
				var phone = [];
				for(var i = 0; i < resultDoc.length; i++){
					if(resultDoc[i].phone){
							phone.push(resultDoc[i].phone);
					}
				}
				phone = Array.from(new Set(phone));
				var options = {
					host: "sms.ssdindia.com",
					path: "/api/sendhttp.php?authkey=16219A1XqcapeE5ae6efbc&mobiles="+phone+"&message="+encodeURIComponent(msg)+"&sender=HEALTH&route=1&country=0"
				};
				console.log(options.path);
				http.get(options, function(r) {
					console.log('STATUS: ' + r.statusCode);
				});
				    	db.close();
			});
		});    
		}		
  		});
	});
	


	/*

		*/
	}

	res.writeHead(200, {'Content-Type': 'text/plain'});
    res.end('OK');
});


app.get('/tempfetch', function(req, res) {
	var user = req.session.user;
	var ip = req.session.ip;
MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("healthplus");
  	
  	 var query = {uname: user.uname};
  	dbo.collection("temperature").find(query).toArray(function(err, result_temp) {
    if (err) throw err;
 		   res.render('temp',{user: user,temp: result_temp, ip: ip});
			});
    
    db.close();
  	
  	
  	});
    }); 


app.get('/pulse', function(req, res){

	var uname = req.query.user;
	var data = req.query.res;

	io.emit('pulse', {value : data+"" , uname : uname+""});

	//MongoDb insert sensor data
	
	if(data != -1){

	MongoClient.connect(url, function(err, db) {
 	 	if (err) throw err;
  		var dbo = db.db("healthplus");
  		var myobj = { uname: uname+"", data: data+"", unit: "BPM", timestamp: new Date().toString()+"" };
  		dbo.collection("pulse rate").insertOne(myobj, function(err, res) {
    	if (err) throw err;
    	console.log("1 document inserted");
				if(parseInt(data) > 100 || parseInt(data) < 60){
		dbo.collection("users").findOne({uname: uname+""},function(err, result) {
			dbo.collection("doctor").find({"uname" : { $in : result.docid  } } ).toArray(function(err, resultDoc) { 
				if (err) throw err;
				var msg = "From "+ uname + ",\nHealth Plus Alert!\nPulse Rate : " + data + "\n\n" + "Patient needs Medical Attention.";
				var phone = [];
				for(var i = 0; i < resultDoc.length; i++){
					if(resultDoc[i].phone){
							phone.push(resultDoc[i].phone);
					}
				}
				phone = Array.from(new Set(phone));
				var options = {
					host: "sms.ssdindia.com",
					path: "/api/sendhttp.php?authkey=16219A1XqcapeE5ae6efbc&mobiles="+phone+"&message="+encodeURIComponent(msg)+"&sender=HEALTH&route=1&country=0"
				};
				console.log(options.path);
				http.get(options, function(r) {
					console.log('STATUS: ' + r.statusCode);
				});
				    	db.close();
			});
		});    
		}
  		});
	});
	
	}

	
	res.writeHead(200, {'Content-Type': 'text/plain'});
    res.end('OK');
});

//pulsefetch

app.get('/pulsefetch', function(req, res) {
	var user = req.session.user;
	var ip = req.session.ip;
MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("healthplus");
  	
  	 var query = {uname: user.uname};
  	dbo.collection("pulse rate").find(query).toArray(function(err, result_pulse) {
    if (err) throw err;
 		   res.render('pulse',{user: user,pulse: result_pulse, ip: ip});
			});
    
    db.close();
  	
  	
  	});
    }); 

app.get('/ecgfetch', function(req, res){
	var user = req.session.user;
	var ip = req.session.ip;

	MongoClient.connect(url, function(err, db) {
		if (err) throw err;
		var dbo = db.db("healthplus");
		var query = {uname: user.uname};
		dbo.collection("ecg_diagnosis").find(query).toArray(function(err, result_ecg) {
		if (err) throw err;
 		   res.render('heart',{user: user,ecg: result_ecg, ip: ip});
		}); 
		db.close();
  	});
});

app.get('/hrv_img', function (req, res) {
	if(!req.session.user){
		res.writeHead(404, {'Content-Type': 'text/plain'});
		res.end('NOT FOUND');
	}else{
		var path = __dirname+"/ecg/"+req.query.user+"/"+req.query.ts+"/ecg.png";
		//console.log(path);
		res.sendFile(path);
	}
});
app.get('/ecg', function(req, res){
	var uname = req.query.user;
	var data = req.query.res;
	//var data= [591,579,597,594,592,605,594,590,567,536,428,293,377,708,835,766,732,702,631,586,588,568,576,569,559,564,552,552,550,537,553,541,536,532,514,522,500,494,502,487,497,490,496,531,536,562,586,582,606,600,609,602,595,607,606,607,602,596,610,590,593,598,588,594,581,596,607,592,598,588,580,594,586,605,590,588,603,586,588,586,592,600,582,588,588,580,586,578,579,568,564,550,526,559,567,574,592,582,591,592,589,606,586,586,578,547,506,340,296,594,840,772,729,713,624,601,596,582,590,590,594,592,578,578,568,573,580,558,567,552,543,546,525,516,521,519,523,522,552,573,582,615,621,643,649,636,652,646,656,653,642,657,653,653,646,634,636,643,654,672,658,656,639,644,646,619,644,654,637,646,648,665,666,646,653,640,652,654,634,644,642,649,636,605,624,616,617,626,626,656,643,643,670,667,666,662,668,666,642,634,569,393,429,714,882,825,792,788,692,661,654,636,643,645,629,628,628,633,626,620,614,600,606,594,591,591,567,557,547,549,544,542,562,568,586,618,617,638,650,639,651,633,632,637,634,639,624,618,632,619,627,615,615,613,601,596,598,604,598,586,598,590,594,589,581,586,570,579,576,553,561,552,532,512,507,524,516,546,562,564,556,545,554,549,542,552,528,512,412,266,302,585,758,691,661,649,577,543,534,518,523,518,508,514,493,495,494,486,477,469,478,474,460,457,438,438,428,410,417,414,434,454,470,495,494,506,526,525,523,516,514,522,522,532,519,522,519,512,516,516,516,521,513,514,506,513,519,513,517,516,514,522,513,499,497,485,469,442,476,489,499,531,525,522,532,521,528,526,517,528,511,502,404,257,279,566,758,704,655,640,567,536,514,501,508,493,494,493,485,495,486,481,476,483,477,454,457,449,436,438,422,416,413,424,448,459,488,517,519,529,533,553,545,545,549,546,554,550,541,547,542,542,544,540,546,535,545,547,535,541,544,542,547,535,541,536,533,523,517,518,504,493,489,494,512,523,542,549,542,543,546,545,556,543,544,521,487,384,256,364,708,774,692,672,618,557,543,545,532,526,528,524,522,505,514,508,499,499,481,485,470,457,462,447,440,441,429,437,446,465,495,508,541,536,543,557,555,561,561,566,561,556,562,548,556,566,546,557,553,549,557,542,552,566,564,570,554,560,569,560,567,555,584,596,610,596,610,606,598,617,602,586,582,562,573,582,581,608,612,618,627,616,616,616,610,614,610,600,595,504,366,345,590,832,802,749,766,689,633,624,608,607,605,601,602,592,605,610,592,600,604,602,607,590,585,592,580,576,586,569,559,555,544,569,588,598,634,640,654,674,666,674,685,673,680,672,663,675,672,670,672,656,668,662,648,658,654,645,652,637,644,637,626,632,621,628,630,609,615,614,598,609,606,592,592,589,590,588,576,573,572,564,546,555,556,560,558,568,557,543,538,517,500,512,513,525,540,536,538,525,524,532,506,497,495,471,452,436,313,200,216,464,662,607,571,580,501,469,454,437,437,429,426,430,422,414,411,404,427,410,399,405,397,389,388,379,376,375,365,366,365,353,367,377,405,429,429,453,464,465,482,475,480,488,475,481,490,489,494,486,484,500,494,487,490,487,493,494,486,488,488,494,499,495,496,500,493,505,504,495,504,507,500,494,494,502,514,500,500,509,504,507,505,507,520,508,484,484,464,461,469,475,512,508,512,523,517,516,521,512,517,512,499,489,434,294,218,366,675,748,656,646,624,552,526,513,508,514,497,499,497,484,504,494,480,495,483,477,488,461,464,464,452,450,436,429,446,437,440,456,459,486,513,528,548,545,556,570,562,564,571,573,572,566,572,579,567,562,577,564,573,569,566,578,570,561,572,567,567,576,564,576,576,564,577,577,574,580,572,573,579,577,579,573,568,581,569,568,573,564,570,572,560,572,567,555,559,532,534,547,547,580,582,573,582,580,572,585,581,572,570,550,542,442,283,340,625,809,770,692,693,643,585,576,567,554,561,549,538,542,535,541,538,521,532,525,514,528,510,495,496,488,489,481,457,475,474,475,499,512,535,556,556,580,585,576,598,598,600,600,589,600,600,585,598,580,588,594,576,594,590,579,588,578,579,579,570,585,585,570,584,582,578,580,555,586,581,553,566,576,567,574,566,564,576,570,579,571,561,578,564,564,564,538,536,538,538,560,569,566,566,564,570,564,558,565,567,554,546,494,362,288,413,747,758,685,703,657,594,573,554,556,553,542,546,545,529,532,522,521,591,579,597,594,592,605,594,590,567,536,428,293,377,708,835,766,732,702,631,586,588,568,576,569,559,564,552,552,550,537,553,541,536,532,514,522,500,494,502,487,497,490,496,531,536,562,586,582,606,600,609,602,595,607,606,607,602,596,610,590,593,598,588,594,581,596,607,592,598,588,580,594,586,605,590,588,603,586,588,586,592,600,582,588,588,580,586,578,579,568,564,550,526,559,567,574,592,582,591,592,589,606,586,586,578,547,506,340,296,594,840,772,729,713,624,601,596,582,590,590,594,592,578,578,568,573,580,558,567,552,543,546,525,516,521,519,523,522,552,573,582,615,621,643,649,636,652,646,656,653,642,657,653,653,646,634,636,643,654,672,658,656,639,644,646,619,644,654,637,646,648,665,666,646,653,640,652,654,634,644,642,649,636,605,624,616,617,626,626,656,643,643,670,667,666,662,668,666,642,634,569,393,429,714,882,825,792,788,692,661,654,636,643,645,629,628,628,633,626,620,614,600,606,594,591,591,567,557,547,549,544,542,562,568,586,618,617,638,650,639,651,633,632,637,634,639,624,618,632,619,627,615,615,613,601,596,598,604,598,586,598,590,594,589,581,586,570,579,576,553,561,552,532,512,507,524,516,546,562,564,556,545,554,549,542,552,528,512,412,266,302,585,758,691,661,649,577,543,534,518,523,518,508,514,493,495,494,486,477,469,478,474,460,457,438,438,428,410,417,414,434,454,470,495,494,506,526,525,523,516,514,522,522,532,519,522,519,512,516,516,516,521,513,514,506,513,519,513,517,516,514,522,513,499,497,485,469,442,476,489,499,531,525,522,532,521,528,526,517,528,511,502,404,257,279,566,758,704,655,640,567,536,514,501,508,493,494,493,485,495,486,481,476,483,477,454,457,449,436,438,422,416,413,424,448,459,488,517,519,529,533,553,545,545,549,546,554,550,541,547,542,542,544,540,546,535,545,547,535,541,544,542,547,535,541,536,533,523,517,518,504,493,489,494,512,523,542,549,542,543,546,545,556,543,544,521,487,384,256,364,708,774,692,672,618,557,543,545,532,526,528,524,522,505,514,508,499,499,481,485,470,457,462,447,440,441,429,437,446,465,495,508,541,536,543,557,555,561,561,566,561,556,562,548,556,566,546,557,553,549,557,542,552,566,564,570,554,560,569,560,567,555,584,596,610,596,610,606,598,617,602,586,582,562,573,582,581,608,612,618,627,616,616,616,610,614,610,600,595,504,366,345,590,832,802,749,766,689,633,624,608,607,605,601,602,592,605,610,592,600,604,602,607,590,585,592,580,576,586,569,559,555,544,569,588,598,634,640,654,674,666,674,685,673,680,672,663,675,672,670,672,656,668,662,648,658,654,645,652,637,644,637,626,632,621,628,630,609,615,614,598,609,606,592,592,589,590,588,576,573,572,564,546,555,556,560,558,568,557,543,538,517,500,512,513,525,540,536,538,525,524,532,506,497,495,471,452,436,313,200,216,464,662,607,571,580,501,469,454,437,437,429,426,430,422,414,411,404,427,410,399,405,397,389,388,379,376,375,365,366,365,353,367,377,405,429,429,453,464,465,482,475,480,488,475,481,490,489,494,486,484,500,494,487,490,487,493,494,486,488,488,494,499,495,496,500,493,505,504,495,504,507,500,494,494,502,514,500,500,509,504,507,505,507,520,508,484,484,464,461,469,475,512,508,512,523,517,516,521,512,517,512,499,489,434,294,218,366,675,748,656,646,624,552,526,513,508,514,497,499,497,484,504,494,480,495,483,477,488,461,464,464,452,450,436,429,446,437,440,456,459,486,513,528,548,545,556,570,562,564,571,573,572,566,572,579,567,562,577,564,573,569,566,578,570,561,572,567,567,576,564,576,576,564,577,577,574,580,572,573,579,577,579,573,568,581,569,568,573,564,570,572,560,572,567,555,559,532,534,547,547,580,582,573,582,580,572,585,581,572,570,550,542,442,283,340,625,809,770,692,693,643,585,576,567,554,561,549,538,542,535,541,538,521,532,525,514,528,510,495,496,488,489,481,457,475,474,475,499,512,535,556,556,580,585,576,598,598,600,600,589,600,600,585,598,580,588,594,576,594,590,579,588,578,579,579,570,585,585,570,584,582,578,580,555,586,581,553,566,576,567,574,566,564,576,570,579,571,561,578,564,564,564,538,536,538,538,560,569,566,566,564,570,564,558,565,567,554,546,494,362,288,413,747,758,685,703,657,594,573,554,556,553,542,546,545,529,532,522,521,591,579,597,594,592,605,594,590,567,536,428,293,377,708,835,766,732,702,631,586,588,568,576,569,559,564,552,552,550,537,553,541,536,532,514,522,500,494,502,487,497,490,496,531,536,562,586,582,606,600,609,602,595,607,606,607,602,596,610,590,593,598,588,594,581,596,607,592,598,588,580,594,586,605,590,588,603,586,588,586,592,600,582,588,588,580,586,578,579,568,564,550,526,559,567,574,592,582,591,592,589,606,586,586,578,547,506,340,296,594,840,772,729,713,624,601,596,582,590,590,594,592,578,578,568,573,580,558,567,552,543,546,525,516,521,519,523,522,552,573,582,615,621,643,649,636,652,646,656,653,642,657,653,653,646,634,636,643,654,672,658,656,639,644,646,619,644,654,637,646,648,665,666,646,653,640,652,654,634,644,642,649,636,605,624,616,617,626,626,656,643,643,670,667,666,662,668,666,642,634,569,393,429,714,882,825,792,788,692,661,654,636,643,645,629,628,628,633,626,620,614,600,606,594,591,591,567,557,547,549,544,542,562,568,586,618,617,638,650,639,651,633,632,637,634,639,624,618,632,619,627,615,615,613,601,596,598,604,598,586,598,590,594,589,581,586,570,579,576,553,561,552,532,512,507,524,516,546,562,564,556,545,554,549,542,552,528,512,412,266,302,585,758,691,661,649,577,543,534,518,523,518,508,514,493,495,494,486,477,469,478,474,460,457,438,438,428,410,417,414,434,454,470,495,494,506,526,525,523,516,514,522,522,532,519,522,519,512,516,516,516,521,513,514,506,513,519,513,517,516,514,522,513,499,497,485,469,442,476,489,499,531,525,522,532,521,528,526,517,528,511,502,404,257,279,566,758,704,655,640,567,536,514,501,508,493,494,493,485,495,486,481,476,483,477,454,457,449,436,438,422,416,413,424,448,459,488,517,519,529,533,553,545,545,549,546,554,550,541,547,542,542,544,540,546,535,545,547,535,541,544,542,547,535,541,536,533,523,517,518,504,493,489,494,512,523,542,549,542,543,546,545,556,543,544,521,487,384,256,364,708,774,692,672,618,557,543,545,532,526,528,524,522,505,514,508,499,499,481,485,470,457,462,447,440,441,429,437,446,465,495,508,541,536,543,557,555,561,561,566];
	io.emit('ecg', {value : data , uname : uname+""});
	res.writeHead(200, {'Content-Type': 'text/plain'});
    res.end('OK');
});

app.get('/hrv', function(req, res){
	var ecg = JSON.parse(req.query.ecg);
	var csv = ecg[0]+"";
	var timestamp = Date.now();
	var uname = req.session.user.uname;
	
	for(var i = 1; i < ecg.length; i++){
		csv += "\n"+ecg[i];
	}
	
	var dir = './ecg/'+uname;

	try {
		fs.statSync(dir);
	} catch(e) {
		fs.mkdirSync(dir);
	}
  
	dir += "/"+timestamp;
  
  	try {
		fs.statSync(dir);
	} catch(e) {
		fs.mkdirSync(dir);
	}
	
	console.log(dir);

	fs.writeFile(dir+'/ecg.csv', csv, function (err) {
		if (err) throw err;
		console.log('Saved!');
		
			var options = {
			mode: 'text',
			//pythonPath: 'path/to/python',
			pythonOptions: ['-u'], // get print results in real-time
			//scriptPath: 'path/to/my/scripts',
			args: [dir+'']
		};

		PythonShell.run('ecg/process.py', options, function (err, result) {
			if (err) throw err;
			// results is an array consisting of messages collected during execution
			var json = JSON.parse(result[2].replace(/'/g, '"'));
			MongoClient.connect(url, function(err, db) {
				if (err) throw err;
				var dbo = db.db("healthplus");
				var myobj = { uname: uname+"", timestamp: timestamp, data : json };
				dbo.collection("ecg_diagnosis").insertOne(myobj, function(err, res1) {
					if (err) throw err;
					console.log("1 document inserted");
					db.close();
					res.writeHead(200, {'Content-Type': 'application/json'});
					res.end(JSON.stringify(myobj));
				});
			});
		});
	});
});



app.get('/insert', function(req, res) {
  	
    
	var fname = req.query.fname;
	var lname = req.query.lname;
	var ename = req.query.ename;
	var uname = req.query.uname;
	var pass1 = req.query.pass1;
	var pass2 = req.query.pass2;

    MongoClient.connect(url, function(err, db) {

    	//find

    	//----
  		if (err) throw err;
  		var dbo = db.db("healthplus");
  		var user = { fname: fname+"", lname: lname+"", ename: ename+"", uname: uname+"", pass1: pass1+"", docid: []};
  			 dbo.collection("users").findOne({uname: uname+""},function(err, result) {
    			if (err) throw err;
				console.log(result);
    			if (result != null) {			
    				console.log("Signup Error");
					res.redirect('/patientSignup?err=1');
    			
    			}else{
					dbo.collection("users").insertOne(user, function(err, result1) {
						if (err) throw err;
						console.log("1 document inserted");
						db.close();
						res.redirect('/patientLogin');
				  	});
    			}
  			});

	});
});

//docSignUp

app.get('/docinsert', function(req, res) {
  	
    
	var fname = req.query.fname;
	var lname = req.query.lname;
	var ename = req.query.ename;
	var uname = req.query.uname;
	var pass1 = req.query.pass1;
	var pass2 = req.query.pass2;

    MongoClient.connect(url, function(err, db) {

    	//find

    	//----
  		if (err) throw err;
  		var dbo = db.db("healthplus");
  		var user = { fname: fname+"", lname: lname+"", ename: ename+"", uname: uname+"", pass1: pass1+"" };
		 dbo.collection("doctor").findOne({uname: uname+""},function(err, result) {
    			if (err) throw err;
				console.log(result);
    			if (result != null) {			
    				console.log("Signup Error");
					res.redirect('/doctor/docsignup?err=1');
    			
    			}else{
					dbo.collection("doctor").insertOne(user, function(err, result1) {
						if (err) throw err;
						console.log("1 document inserted");
						db.close();
						res.redirect('/doctor/doclogin');
				  	});
    			}
  			});

	});

});





app.get('/', function(req, res) {
		res.redirect('/patientLogin');
});

app.get('/connect', function(req, res) {
	var user = req.session.user;
	var ip = req.query.ip;
	var options = {
		//host: 'www.facebook.com'
  		host: ip+'',
  		path: '/connect?uname='+user.uname
	};
	http.get(options, function(r) {
  		console.log('STATUS: ' + r.statusCode);
  		console.log('HEADERS: ' + JSON.stringify(r.headers));
  		req.session.ip = ip;
		res.writeHead(200, {'Content-Type': 'text/plain'});
		res.end('OK');
	}).on('error', function(e) {
		req.session.ip = null;
		console.log("Got error: " + e.message);
		res.writeHead(404, {'Content-Type': 'text/plain'});
		res.end('Error');
	});
});

app.get('/docprof', function(req, res) {
		var uname = req.query.duname;
		var user =  req.session.user.uname;
		
	MongoClient.connect(url, function(err, db) {
		if (err) throw err;
  		var dbo = db.db("healthplus");
  		dbo.collection("users").findOne({uname: user}, function(err, result_user) {
    		if (err) throw err;
  		dbo.collection("doctor").findOne({uname: uname}, function(err, result) {
    		if (err) throw err;
    		
    		var query = {from: user, to: uname};
    	dbo.collection("chat").find(query).toArray(function(err, result_chat1) {
    		if (err) throw err;	
    		var query = {from: uname, to: user}
    	dbo.collection("chat").find(query).toArray(function(err, result_chat2) {
    		var result_chat = result_chat1.concat(result_chat2);
    		result_chat.sort(function(a, b) {
    		return parseFloat(a.timestamp) - parseFloat(b.timestamp);
			});
    		
    		if (err) throw err;		
    	    if (result) {

    			res.render('docprof',{doc : result , user : result_user, chat: result_chat });
    		}else{
    		    console.log("Doctor Not Found!");
    		}
    	db.close();
  });
    	  });
    });
    });
  });
});

//patientprof
app.get('/patientprof', function(req, res) {
		var uname = req.query.puname;
		var user =  req.session.user.uname;
	MongoClient.connect(url, function(err, db) {
		if (err) throw err;
  		var dbo = db.db("healthplus");
  		dbo.collection("users").findOne({uname: uname}, function(err, result) {
    		if (err) throw err;
    		var query = {uname: uname};
    	dbo.collection("temperature").find(query).toArray(function(err, result_temp) {
   		 if (err) throw err;
    		var query = {uname: uname};
    	dbo.collection("pulse rate").find(query).toArray(function(err, result_pulse) {
    	if (err) throw err;	
		dbo.collection("ecg_diagnosis").find(query).toArray(function(err, result_ecg) {
    	if (err) throw err;	
    		
    	var patname = result.uname;
    		var query = {from: user, to: patname};
    	dbo.collection("chat").find(query).toArray(function(err, result_chat1) {
    		if (err) throw err;	
    		var query = {from: patname, to: user};
    	dbo.collection("chat").find(query).toArray(function(err, result_chat2) {
    		var result_chat = result_chat1.concat(result_chat2);
    		var final_chat = result_chat.sort({timestamp: -1});
    		result_chat.sort(function(a, b) {
    		return parseFloat(a.timestamp) - parseFloat(b.timestamp);
			});
    		if (err) throw err;			
    	    if (result) {
    			res.render('patientprof',{patprof : result, pattemp : result_temp, patpulse : result_pulse, patecg : result_ecg, user : user+"", chat: result_chat});
    		}else{
    		    console.log("patient Not Found!");
    		}
    	db.close();
		 });
		});
		});
    	});
    	});
    });
  });
});


app.get('/home', function(req, res) {
	var user = req.session.user;
	var ip = req.session.ip;
MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("healthplus");
  	
  	 var query = {uname: user.uname};
  	dbo.collection("temperature").find(query).toArray(function(err, result_temp) {
    if (err) throw err;
    
    dbo.collection("pulse rate").find(query).toArray(function(err, result_pulse) {
    if (err) throw err;
	
	dbo.collection("ecg_diagnosis").find(query).toArray(function(err, result_ecg) {
    if (err) throw err;

    dbo.collection("doctor").find({}).toArray(function(err, result_doc) {
    if (err) throw err;
		res.render('home',{user: user,temp: result_temp[result_temp.length-1], ecg: result_ecg[result_ecg.length-1], pulse: result_pulse[result_pulse.length-1],ip: ip, doc: result_doc});
    
    db.close();
  	
  	});
  	});
    });
    });

}); 
});

app.get('/dochome', function(req, res) {
	if(!req.session.user){
		console.log("Session Empty");
		res.redirect('/patientLogin');
	}else{
		console.log("Session OK");
		var user = req.session.user;
		MongoClient.connect(url, function(err, db) {
			if (err) throw err;
			var dbo = db.db("healthplus");
  	
			var uname = user.uname;
			dbo.collection("users").find({ docid: uname }).toArray(function(err, result_patient) {
				if (err) throw err;
				if (result_patient) {
					res.render('dochome',{patient : result_patient, user: user});
				}else{
					console.log("Patients Not Found!");
				}
				db.close();
			});
		});
	}
});

app.get('/patientAuth', function(req, res) {

		var uname = req.query.uname;
		var pass = req.query.pass;

	MongoClient.connect(url, function(err, db) {
		if (err) throw err;
  		var dbo = db.db("healthplus");
  		dbo.collection("users").findOne({uname: uname, pass1: pass}, function(err, result) {

    		if (err) throw err;
    	    if (result) {
    	    	// set session variable fname 
    	    	//if(req.session){
				req.session.user = result;
    	    	//fname = result.fname;
    			res.redirect('/home'); 
    		}else{
    		    console.log("Login Error");
				res.redirect('/patientLogin?err=1');
    		}
    	db.close();
  });
  });
});

//doclogin
app.get('/docauth', function(req, res) {

		var uname = req.query.uname;
		var pass = req.query.pass;

	MongoClient.connect(url, function(err, db) {
		if (err) throw err;
  		var dbo = db.db("healthplus");
  		dbo.collection("doctor").findOne({uname: uname, pass1: pass}, function(err, result) {
    		if (err) throw err;
    	    if (result) {
    	    	// set session variable fname 
    	    	//if(req.session){
				req.session.user = result;
				var user = result;

    			res.redirect('/dochome'); 

    		}else{
    		    console.log("Login Error");
				res.redirect('/doctor/doclogin?err=1');
    		}
    	db.close();
  });
  });
});


//update database
	app.get('/update', function(req, res) {
  	var user = req.session.user;
    var uname         = user.uname;
	var fname         = req.query.fname;
	var lname         = req.query.lname;
	var ename         = req.query.ename;
	var pass1         = req.query.pass1;
	var dob           = req.query.dob;
	var phone         = req.query.phone;
	var bg            = req.query.bg;
	var weight        = req.query.weight;
	var height        = req.query.height;
	var disease       = req.query.disease;
	var description   = req.query.description;
	var docid         = req.query.docid;


	MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("healthplus");
  var myquery = { uname: uname+""}; 
  var updatedData = {uname: uname, fname: fname, lname: lname, ename: ename, pass1: pass1, dob:dob, phone: phone, bloodgroup: bg,
  				weight: weight, height: height, disease: disease, description: description};
  var newvalues = { $set: updatedData};
  dbo.collection("users").updateOne(myquery, newvalues, function(err, result) {
    if (err) throw err;
    console.log("1 document updated");
	
     		dbo.collection("users").findOne({uname: uname}, function(err, result) {

    		if (err) throw err;
				req.session.user = result;
    			res.redirect('/home'); 
			db.close();
			
		});
  });
}); 
});

//updatedoc
app.get('/updatedoc', function(req, res) {
  	var user = req.session.user;
    var uname         = user.uname;
	var fname         = req.query.fname;
	var lname         = req.query.lname;
	var ename         = req.query.ename;
	var pass1         = req.query.pass1;
	var dob           = req.query.dob;
	var phone         = req.query.phone;
	var hospital      = req.query.hospital;
	var qualification      = req.query.qualification;
	var specialization      = req.query.specialization;
	
	MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("healthplus");
  var myquery = { uname: uname+""}; 
  var updatedData = {uname: uname, fname: fname, lname: lname, ename: ename, pass1: pass1, dob:dob, phone: phone, hospital: hospital,
  						qualification: qualification, specialization: specialization};
  var newvalues = { $set: updatedData};
  dbo.collection("doctor").updateOne(myquery, newvalues, function(err, result) {
    if (err) throw err;
    console.log("1 document updated");
   
    req.session.user = updatedData;
   
    res.redirect('/dochome');
    db.close();
  });
}); 
});
//add doc
app.get('/adddoc', function(req, res) {

	var user = req.session.user;
    var uname = user.uname;
    var doctorid = req.query.doctorid;
  

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("healthplus");
 dbo.collection("users").findOne({uname: uname}, function(err,result) {
   if(result.docid){
   	   result.docid.push( doctorid+"" );
   }else{
   		result.docid = [doctorid];
   }

     dbo.collection("users").updateOne({uname: uname}, {$set: result}, function(err, r) {
   		 if (err) throw err;
    	 console.log("1 document updated");
    	req.session.user = result;
    	res.redirect('/home');
    	db.close();
    });
  });
}); 
});

//removedoc
app.get('/removedoc', function(req, res) {

	var user = req.session.user;
    var doctorid = req.query.doctorid;
    var index = user.docid.indexOf(doctorid);
     if (index > -1) {
      user.docid.splice(index, 1);
    }
    delete user['_id'];

 MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("healthplus");
  var myquery = { uname: user.uname+""}; 
  var newvalues = { $set: user};
  dbo.collection("users").updateOne(myquery, newvalues, function(err, result) {
    if (err) throw err;
    console.log("1 document updated");
   
    req.session.user = user;
    
    res.redirect('/home');
    db.close();
  });
}); 
});

//logout
app.get('/logout',function(req, res){
  req.session.destroy(function(){
  	console.log("logout success");
    res.redirect('/patientLogin');
  });
}); 

//logout doc
app.get('/logoutdoc',function(req, res){
  req.session.destroy(function(){
  	console.log("logout success");
    res.redirect('/doctor/doclogin');
  });
}); 


// insert page 
app.get('/patientSignup', function(req, res) {
	var error = "";
	if (req.query.err == 1) {
		error = "username exist!";
	}
  res.render('patientSignup', {error : ""+error });
});

app.get('/doctor/docsignup', function(req, res) {
	var error = "";
	if (req.query.err == 1) {
		error = "username exist!";
	}
  res.render('doctor/docsignup', {error : ""+error });
});


app.get('/patientLogin', function(req, res) {
	var error = "";
	if(req.query.err == 1 ){
		error = "Login Error, invalid input!";
	}
	res.render('patientLogin', {error : ""+error,success: false, fname: req.session.fname });
});

app.get('/doctor/doclogin', function(req, res) {
	var error = "";
	if(req.query.err == 1 ){
		error = "Login Error, invalid input!";
	}
	res.render('doctor/doclogin', {error : ""+error});
});

console.log('Connected Port 3000');
